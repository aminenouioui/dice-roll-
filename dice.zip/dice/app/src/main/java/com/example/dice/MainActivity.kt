package com.example.dice

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DiceRollApp()
        }
    }
}

@Composable
fun DiceRollApp() {
    // Dice roll and points state using `remember`
    var diceRoll by remember { mutableStateOf(1) }
    var playerPoints by remember { mutableStateOf(0) }

    // UI layout
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(text = "Dice Roll: $diceRoll", style = MaterialTheme.typography.headlineMedium)

        Spacer(modifier = Modifier.height(16.dp))

        // Display the dice image based on the current diceRoll value
        Image(
            painter = painterResource(id = getDiceImageResource(diceRoll)),
            contentDescription = "Dice Image",
            modifier = Modifier.size(150.dp)  // Size of the dice image
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(text = "Points: $playerPoints", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {
            // Roll the dice and accumulate points
            val newRoll = Random.nextInt(1, 7)
            diceRoll = newRoll
            playerPoints += newRoll
        }) {
            Text(text = "Roll Dice")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {
            // Reset the game
            diceRoll = 1
            playerPoints = 0
        }) {
            Text(text = "Reset Game")
        }
    }
}

// Helper function to return the dice image resource based on the roll
@Composable
fun getDiceImageResource(diceRoll: Int): Int {
    return when (diceRoll) {
        1 -> R.drawable.dice_1
        2 -> R.drawable.dice_2
        3 -> R.drawable.dice_3
        4 -> R.drawable.dice_4
        5 -> R.drawable.dice_5
        else -> R.drawable.dice_6
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    DiceRollApp()
}
